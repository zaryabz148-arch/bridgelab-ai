# DESIGN.md — BridgeLab AI Design System Specification

## 1. Product Overview & Vision
BridgeLab AI is an AI-powered global creative impact studio empowering designers, creative students, marketing teams, and social impact organizations to transform critical social issues into impactful visual campaigns.
**Tagline:** *"Design Ideas. Communicate Impact."*

## 2. Brand Identity & Personality
- **Tone & Mood:** Intelligent, Creative, Elegant, Purposeful, Modern, International, Trustworthy, Minimal but Expressive.
- **Brand Motifs:** Abstract bridge geometry intersecting with subtle communication and creative connection waves. No generic robot/brain icons.

## 3. Master Color Tokens
- `primary`: Deep Navy `#111827`
- `background`: Warm Ivory `#F7F6F2`
- `surface`: Pure White `#FFFFFF`
- `accent-primary`: Electric Cobalt `#315CFF`
- `accent-secondary`: Elegant Teal `#16A085`
- `highlight`: Warm Gold `#D9A441`
- `text-primary`: `#172033`
- `text-secondary`: `#667085`
- `border`: `#E6E8EC`

## 4. Typography Scale (Inter & Noto Arabic/Nastaliq)
- Display 1: 48px / line-height 1.15 / tracking -0.02em / SemiBold to Bold
- Heading 1: 36px / line-height 1.2 / tracking -0.015em
- Heading 2: 24px / line-height 1.3
- Heading 3: 18px / line-height 1.4 / Medium
- Body Large: 16px / line-height 1.6
- Body Base: 14px / line-height 1.5
- Caption / Microcopy: 12px / line-height 1.4 / Medium / uppercase tracking 0.05em

## 5. Layout & Spatial Geometry
- Base Grid: 8px rhythm
- Studio Sidebar Width: 248px fixed
- Studio Header Height: 72px fixed
- Container Max Width: 1280px
- Card Corner Radius: 16px (`rounded-2xl`)
- Button Corner Radius: 12px (`rounded-xl`)
- Input Corner Radius: 10px (`rounded-lg`)

## 6. Components & Design Patterns
- **Buttons:**
  - Primary: Deep Navy `#111827` with white text or Cobalt `#315CFF` with white text, 12px radius, subtle scale/shadow on hover.
  - Secondary/Outline: White `#FFFFFF` background, `#E6E8EC` border, `#172033` text.
  - Ghost: Transparent background, hover:bg-black/5.
- **Cards:** White surface, 1px solid `#E6E8EC`, soft elevation `shadow-[0_4px_20px_rgba(17,24,39,0.03)]`.
- **Badges:** Pill shape (`rounded-full`), subtle background tint (e.g. Teal 10%, Cobalt 10%), bold micro text.
- **Form Controls:** Clean borders, focus ring in Electric Cobalt (`focus:ring-2 focus:ring-[#315CFF]/20 focus:border-[#315CFF]`).

## 7. Sample Themes & Editorial Art Direction
- Equal Access to Education (Warm Gold / Deep Indigo)
- Digital Respect and Online Peace (Electric Cobalt / Soft Cyan)
- Environmental Responsibility (Forest Emerald / Elegant Teal)
All demonstration projects explicitly stamped with `[SAMPLE CONCEPT]`.
