---
name: BridgeLab AI
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#434656'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#747688'
  outline-variant: '#c4c5d9'
  surface-tint: '#154aef'
  primary: '#0040e3'
  on-primary: '#ffffff'
  primary-container: '#315cff'
  on-primary-container: '#f1f0ff'
  inverse-primary: '#b9c3ff'
  secondary: '#006b58'
  on-secondary: '#ffffff'
  secondary-container: '#82f7d8'
  on-secondary-container: '#00725e'
  tertiary: '#724f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#916600'
  on-tertiary-container: '#ffefdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b9c3ff'
  on-primary-fixed: '#001356'
  on-primary-fixed-variant: '#0034bf'
  secondary-fixed: '#82f7d8'
  secondary-fixed-dim: '#65dabc'
  on-secondary-fixed: '#002019'
  on-secondary-fixed-variant: '#005142'
  tertiary-fixed: '#ffdeaa'
  tertiary-fixed-dim: '#f5bd58'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5f4100'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
typography:
  display:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Inter
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies an editorial, intelligent, and purpose-driven aesthetic suited for a global creative impact studio. It merges the structure of modern enterprise SaaS with the refinement of international editorial publication design. The visual tone evokes authority, cultural resonance, and cutting-edge intelligence without coldness or visual clutter. 

The styling pairs warm, tactile canvas tones with crisp digital surfaces, accented by high-precision electric hues and artisanal metallics. Visual elements emphasize deliberate composition, asymmetric balance, generous structural spacing, and meticulous typography that naturally supports cross-cultural and bilingual (LTR/RTL) contexts.

## Colors

The palette establishes an editorial balance through high contrast and deliberate functional assignments:

- **Canvas & Surfaces:** The foundational canvas rests on `#F7F6F2` (Warm Ivory), creating an organic, paper-like atmosphere that eliminates harsh monitor glare. Elevated structural surfaces, cards, modals, and sheets use `#FFFFFF` (Pure White) to cleanly delineate interactive zones.
- **Brand Navy & Typography:** `#111827` (Deep Navy) anchors the brand presence, dominant headers, and key layout frames. Main body content is set in `#172033` for softened reading strain, while `#667085` provides secondary clarity for metadata, captions, and secondary actions.
- **Accents:** `#315CFF` (Electric Cobalt) directs primary interactive focus, active states, key progress indicators, and primary CTAs. `#16A085` (Elegant Teal) serves as a functional secondary accent for success indicators, active verifications, and sustainable impact metrics.
- **Subtle Highlight:** `#D9A441` (Gold Decorative Accent) is applied sparingly to denote editorial curated items, honors, bilingual callouts, and bespoke studio outputs.
- **Dividers & Outlines:** `#E6E8EC` acts as the uniform hairline stroke across all containers and component thresholds.

## Typography

The typographic hierarchy uses Inter for its structural clarity, neutral geometric rhythm, and versatile editorial weight distribution.

- **Editorial Rhythm:** Headlines utilize tight negative tracking (`-0.03em` to `-0.015em`) and deliberate semi-bold weights to convey high editorial impact without relying on high-contrast serifs.
- **Body & Metrics:** Body copy preserves a generous line height (`1.45` to `1.55`) for long-form creative project manifests and intelligence briefs.
- **Multilingual & RTL Strategy:** Bilingual scripts fall back to `Noto Nastaliq Urdu` and `Noto Sans Arabic`. In Urdu and Arabic modes, line heights are globally expanded by a factor of `1.25x` to prevent glyph clipping, while font sizes below `13px` are automatically stepped up to `14px` for optimal calligraphic legibility.

## Layout & Spacing

The architecture operates strictly on an 8-point spatial system:

- **Desktop Framework:** The central application stage conforms to a max-width envelope of `1320px` (or `1280px` standard reading canvas), framed by a persistent `248px` collapsible studio sidebar and a fixed `72px` persistent top navigational bar.
- **Grid Architecture:** Desktop views apply a 12-column layout with `24px` (`1.5rem`) gutters and `32px` (`2rem`) outer margins. Breakpoints scale dynamically:
  - **Desktop (≥ 1280px):** 12 columns, fixed studio navigation, fluid workspace.
  - **Tablet (768px – 1279px):** 8 columns, `16px` gutters, auto-collapsing sidebar to icon-rail or top drawer.
  - **Mobile (< 768px):** 4 columns, `16px` gutters, `16px` canvas margins, persistent top bar pinned at `64px`, bottom action sheets replacing floating panels.
- **RTL Fluidity:** In RTL layout modes, directional layouts mirror symmetrically across the axis: the sidebar anchors to the right, and gutter alignments dynamically re-index without breaking spatial proportions.

## Elevation & Depth

Visual depth is achieved through an interplay of low-contrast surface borders, intentional background contrasts, and delicate ambient shadows:

- **Surface Layering:** The primary canvas rests on `#F7F6F2`. Active cards and content planes rise onto crisp `#FFFFFF` surfaces.
- **Hairline Outlines:** All elevated panels, cards, inputs, and popovers maintain a defined `1px` structural outline in `#E6E8EC`.
- **Soft Ambient Shadows:** Rather than heavy drop shadows, surfaces float with a soft shadow signature: `box-shadow: 0 4px 20px -2px rgba(17, 24, 39, 0.04), 0 2px 6px -1px rgba(17, 24, 39, 0.02)`.
- **Overlays & Modals:** Dialogs and studio drawers use an elevated depth profile (`0 16px 36px -4px rgba(17, 24, 39, 0.08)`) over a backdrop scrim tinted with `#111827` at `20%` opacity and an `8px` blur.

## Shapes

The design system employs a curated geometry scale that distinguishes micro-interactions from macro-containers:

- **Cards & Primary Modules:** Standardized to a `16px` border radius (`rounded-lg`), delivering an approachable, human, yet architectural appearance.
- **Interactive Controls (Buttons, Inputs, Selects):** Standardized to a precise `12px` border radius, creating visual cohesion across active components while preserving distinct interactive signifiers.
- **Chips, Badges, & Status Pills:** Fully rounded / capsule (`9999px`) to immediately communicate metadata, tags, and categorical taxonomy.

## Components

- **Buttons:**
  - *Primary:* Filled `#315CFF` with white text, `12px` corner radius, `44px` height (Desktop) / `48px` (Mobile), `label-lg` styling. Subtle elevation on hover with `2px` translation dampening.
  - *Secondary:* Pure white background, `1px` border in `#E6E8EC`, text `#111827`. Hover state transitions background to `#F7F6F2`.
  - *Teal Action:* Filled `#16A085` with white text for verification, publish, or positive confirmation flows.
- **Cards:**
  - Background `#FFFFFF`, radius `16px`, border `1px` solid `#E6E8EC`, ambient shadow `rgba(17,24,39,0.04)`.
  - Content padding scales uniformly from `24px` (`space-lg`) on desktop to `16px` (`space-md`) on mobile.
- **Input Fields & Form Elements:**
  - Height `44px`, radius `12px`, background `#FFFFFF`, border `1px` solid `#E6E8EC`. 
  - Focus state replaces the border with `#315CFF` and adds a subtle glow: `box-shadow: 0 0 0 3px rgba(49, 92, 255, 0.12)`.
  - Placeholder text in `#667085`.
- **Chips & Status Tags:**
  - Height `28px`, capsule radius (`9999px`), horizontal padding `12px`.
  - *Accent Variant (Gold):* `#D9A441` at `10%` fill, border `rgba(217, 164, 65, 0.3)`, text `#8D6519`.
  - *Teal Variant:* `#16A085` at `10%` fill, border `rgba(22, 160, 133, 0.25)`, text `#0E6655`.
- **Checkboxes & Radios:**
  - Dimensions `20px x 20px`. Checkboxes use `6px` radius; radios are circular.
  - Unchecked: `1.5px` border in `#E6E8EC`, background `#FFFFFF`.
  - Checked: Solid `#315CFF` fill with crisp white vector tick or dot.
- **Iconography:**
  - Lucide-style line icons, uniform `1.75px` stroke weight, bounding box `20px x 20px` (standard) or `16px x 16px` (compact controls). Default color `#667085`, shifting to `#111827` or `#315CFF` on active states.
- **Studio Sidebar & Header Components:**
  - Studio Sidebar (`248px` width): Solid `#FFFFFF` fill with right-edge border `1px` solid `#E6E8EC`.
  - Top Navigation Bar (`72px` height): Frosted `#FFFFFF` or solid `#FFFFFF` with bottom-edge border `1px` solid `#E6E8EC`.